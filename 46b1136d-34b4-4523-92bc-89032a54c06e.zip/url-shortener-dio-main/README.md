# url-shortener-dio

Projeto criado junto da DIO para construção de um Encurtador de URL.

## Rodando o projeto

- `npm install`
- `npm run build`
- `npm run dev`

Algumas informações sobre os vídeos:

- Editor de Texto usado: VSCode
  - Color Theme do editor: Material UI e Bluloco Dark
- Programa para verificar as requests: Insomnia

Informações pessoais:

- Meu linkedin: https://www.linkedin.com/in/alexiapereira/
